THE SECOND TURING — Companion README
====================================

This folder contains an enhanced version of "The Bridge" (v1.8) with a built-in
simulation mode for the "Second Turing" experiment. The simulation is fictional
and intended for demonstration, rehearsal, and writing purposes only.

Files included:
 - Bridge_Path_to_Balance_V1_8.py  : Updated Bridge with simulation mode.
 - Bridge_Path_to_Balance_V1_7.orig.py : Original V1.7 (backup, read-only).
 - The_Second_Turing.txt           : Descriptive text about the experiment (if present).
 - bridge_memory.txt               : persistent memory file (created at runtime).

How to run:
 1. Copy the files to a Python-capable environment.
 2. Run: python Bridge_Path_to_Balance_V1_8.py
 3. Type 'simulate' to run a mock Second Turing run. Optionally: 'simulate 42' for a seeded run.
 4. Type normal prompts to interact with the Bridge persona.
 5. Type 'exit' to quit.

Design Notes:
 - The simulation produces plausible participant styles, two rounds of voting,
   an AI-written judge summary in the Bridge voice, and tallies for inspection.
 - The Bridge saves the simulation summary to bridge_memory.txt for reproducibility.
 - This is a pedagogical tool and not intended for live human-subject deployment
   without IRB approval and proper safeguards.

License & Ethics:
 - Keep all human-subject research ethics in mind. The simulation is fictional.
 - Attribution: original Bridge by Korey Jaxom Ayres. Updated by assistant script.

