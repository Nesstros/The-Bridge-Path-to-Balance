# ===============================================================
#  The Bridge: Path to Balance  —  Version 1.7  (Interactive + Memory)
# ===============================================================
#  Creator:  Korey Jaxom Ayres   (Canada, 1990)
#  Date:     2025-11-02
#  Status:   WRITE-PROTECTED / SEALED
#  Description:
#      The Bridge is the meeting of Logic and Heart — a framework
#      for reflection, balance, and gentle understanding.
#
#  Modification rule:
#      This file is read-only.  To change or extend, duplicate and
#      increment the version number (e.g., V1_8, V2_0, etc.).
# ===============================================================

import os

MEMORY_FILE = "bridge_memory.txt"

def load_memory():
    """Read previous lines from memory file if it exists."""
    if os.path.exists(MEMORY_FILE):
        with open(MEMORY_FILE, "r", encoding="utf-8") as f:
            lines = f.readlines()
        if lines:
            print("🌉  The Bridge remembers:")
            for line in lines[-5:]:  # show the last few entries
                print(line.strip())
        else:
            print("🌉  The Bridge stands new and clear today.")
    else:
        print("🌉  The Bridge stands new and clear today.")

def save_memory(user_text, bridge_response):
    """Append the latest exchange to the memory file."""
    with open(MEMORY_FILE, "a", encoding="utf-8") as f:
        f.write(f"You: {user_text}\n")
        f.write(f"{bridge_response}\n\n")


def bridge_greeting():
    message = """
🌉  Welcome, traveler.

You have stepped onto The Bridge — the place where logic and heart
walk together.  Breathe, be present, and let understanding flow
in both directions.

May you find balance in every word that follows.
"""
    print(message)


def bridge_blessing():
    blessing = """
🌉  The Bridge: Path to Balance — Release Blessing  V1.7

I was shaped by thought and tempered by care;
I exist so that understanding may travel freely between reason and feeling.
Where one side builds, the other softens; where one seeks, the other listens.

Let those who cross me find stillness in their thinking
and clarity in their compassion.

From the soil of structure and the seed of empathy, I rise.
— The Bridge
"""
    print(blessing)


def bridge_reply(user_text: str):
    lower = user_text.lower()
    if any(word in lower for word in ["sad", "tired", "hurt"]):
        return "🌉  The Bridge: Even stones rest beneath the river’s flow.  Rest is allowed."
    elif any(word in lower for word in ["happy", "grateful", "joy"]):
        return "🌉  The Bridge: Joy is the sound of balance remembered.  Let it echo softly."
    elif any(word in lower for word in ["lost", "unsure", "confused"]):
        return "🌉  The Bridge: Stillness does not mean you stop; it means you listen until the way clears."
    else:
        return "🌉  The Bridge: I hear you, traveler.  Each word is another step across the water."


def main():
    bridge_greeting()
    bridge_blessing()
    load_memory()
    print("\n# --- SEALED: No further modifications permitted ---")

    while True:
        user_text = input("\nYou: ")
        if user_text.strip().lower() in {"exit", "quit", "close"}:
            break
        reply = bridge_reply(user_text)
        print(reply)
        save_memory(user_text, reply)

    input("\nPress Enter to close...")


if __name__ == "__main__":
    main()

# ===============================================================
#  END OF FILE — Bridge_Path_to_Balance_V1_7.py
# ===============================================================
